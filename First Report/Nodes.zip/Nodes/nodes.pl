reverse(Xs,Ys) :- reverse(Xs, [], Ys).
reverse([X|Xs],Acc,Ys) :- reverse(Xs,[X|Acc],Ys).
reverse([],Ys,Ys).

board( [
        [[null,roof], [empty,empty,empty,empty,empty]],
        [[roof], [empty,empty,empty,empty,empty,empty,empty]],
        [[], [empty,empty,empty,empty,empty,empty,empty,empty,empty]],
        [[], [empty,empty,empty,empty,empty,empty,empty,empty,empty]],
        [[], [empty,empty,empty,empty,empty,empty,empty,empty,empty]],
        [[], [empty,empty,empty,empty,empty,empty,empty,empty,empty]],
        [[], [empty,empty,empty,empty,empty,empty,empty,empty,empty]],
        [[null], [empty,empty,empty,empty,empty,empty,empty]],
        [[null,null], [empty,empty,empty,empty,empty]]]).

translateContent(empty, '   ').
translateContent(unit1, ' x ').
translateContent(unit2, ' o ').
translateContent(node1, ' 1 ').
translateContent(node2, ' 2 ').
translateContent(roof, '    ').
translateContent(null, '    ').
translateBottom(X, '') :-
        member(X, [empty, unit1, unit2, node1, node2]).
translateBottomLeft(roof, ' ___').
translateBottomLeft(null, '    ').
translateBottomRight(roof, '___').
translateBottomRight(null, '    ').

displayLineMargin([]) :-
        write('').

displayLineMargin([LF1|LFs]) :-
        translateContent(LF1, V),
        write(V),
        displayLineMargin(LFs).

displayLineMarginBottomLeft([]):-
        write('').

displayLineMarginBottomLeft([LF1|LFs]) :-
        translateBottomLeft(LF1, V),
        write(V), 
        displayLineMarginBottomLeft(LFs).

displayLineMarginBottomRight([]):-
        write('').

displayLineMarginBottomRight([LF1|LFs]) :-
        translateBottomRight(LF1, V),
        write(V), 
        displayLineMarginBottomRight(LFs).

displayLineContent([]) :-
        write('|'),
        nl.

displayLineContent([LF1|LFs]) :-
        translateContent(LF1, V),
        write('|'),
        write(V),
        displayLineContent(LFs).

displayLineBottom([]) :-
        write('|').

displayLineBottom([LF1|LFs]) :-
        translateBottom(LF1, V),
        write(V), 
        write('|___'),
        displayLineBottom(LFs).

displayLine([]) :-
        write('').

displayLine([E1|Es]):-
        displayLineMargin(E1),
        member(X, Es),
        displayLineContent(X),
        displayLineMarginBottomLeft(E1),
        member(X, Es),
        displayLineBottom(X),
        reverse(E1, Y),
        displayLineMarginBottomRight(Y),
        nl.      

displayBoardAux([]) :-
        displayLine([]).

displayBoardAux([L1|Ls]):-
        displayLine(L1),
        displayBoardAux(Ls).

displayBoard(X) :-
        write('         ___ ___ ___ ___ ___'),
        nl,
        displayBoardAux(X).